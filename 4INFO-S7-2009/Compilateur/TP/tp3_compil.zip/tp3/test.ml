begin int x, int y ; x <- x + y end
