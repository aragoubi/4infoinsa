
let _ = 
try
 (* let lexbuf= Lexing.from_channel stdin in*)
  let lexbuf= Lexing.from_channel (open_in "test.ml") in
while true do
 Parser.main Lexer_crible.get_token lexbuf 
done
with Lexer_crible.EOF ->print_string "analyse reussie";exit (0);;

