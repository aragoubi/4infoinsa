#use "parser.ml";;
#use "lexer_crible.ml";;

(*************************FICHIER de TEST *************************************)


(*let lexbuf = Lexing.from_channel (open_in "test");;*)
 let lexbuf = Lexing.from_string "begin end a1 a b ; 
 , ( ( ) <- + < and end int bool";; 


(* fonction de test, qui donne la liste des token d'un objet Lexing.*)
 let rec  test_get_token = function lex ->
   let tok = get_token lex in  match tok with
       EOF -> [EOF]
     | a -> a::(test_get_token lex);;

(************  TEST DE GET TOKEN **********************************************) 
(*On verifie que tout les tokens sont bien reconnus*)

test_get_token lexbuf;;
(*- : token list =
[BEGIN; END; IDENT "a1"; IDENT "a"; IDENT "b"; POINTVIRGULE; VIRGULE; PAROUV;
 PAROUV; PARFERM; FLECHE; PLUS; INF; AND; END; INT; BOOL; EOF]*)

(*Tout les token sont reconnus. *)

(***************** test d'un caract�re non reconnu********************)
let lexerror = Lexing.from_string "begin {";;
test_get_token lexerror;;

(* lorsqu'un caract�re n'est pas reconnu, une exception Exception: Failure "lexing: empty token". est automatiquement lev�.
notre analyseur lexical ne g�re pas les erreurs.*)

(***************************TEST DE L'ANALYSEUR SYNTAXIQUE******************************)

main get_token (Lexing.from_string "begin int a ; a <- b + c end");;
  
(* *         - : bloc =
([("a", GINT)], [Affectation ("a", Addition (Variable "b", Variable "c"))])*)

(* le test est bien dans la grammaire. L'arbre abstrait cr�� est correct.*)

main get_token (Lexing.from_string "begin int c ; bool end  b + c end");;
(*le test nest pas dans la grammaire. Une exception  Exception: Parsing.Parse_error. est donc lev�e.*)

main get_token (Lexing.from_string "begin int a, bool b, bool c, int d ; a <- ((b + c) <  d) + c; begin int truc; truc <- truc end end");;
(* test avec qui regroupe tout les caract�res et toutes les r�gles. On imbrique deux parenth�se, et on fait deux "bloc".
Le r�sultat obtenu est correct!
#     - : bloc =
([("a", GINT); ("b", GBOOL); ("c", GBOOL); ("d", GINT)],
 [Affectation ("a",
   Addition
    (Comparaison (Addition (Variable "b", Variable "c"), Variable "d"),
    Variable "c"));
  Bloc ([("truc", GINT)], [Affectation ("truc", Variable "truc")])])
*)

(*CONCLUSION DES TEST.*)

(*Malgr�s la non gestion des erreurs (lors de lecture de caract�re innatendus), l'analyseur syntaxique et s�mantique fonctionnent correctement.*)

(* REPONSES AUX QUESTIONS *)

(* Q1. Le fait d'utiliser ocamlex avec un crible permet de reduire
 le nombre d'etats de la table SLR que sans crible (de 28 etats à 11 états)

Q2. 

 *)
