type token =
  | BEGIN
  | POINTVIRGULE
  | AND
  | END
  | INT
  | BOOL
  | FLECHE
  | PLUS
  | PAROUV
  | PARFERM
  | EOF
  | INF
  | VIRGULE
  | IDENT of (string)

open Parsing;;
# 12 "parser.mly"
  type gtype= GINT | GBOOL;;
  type declaration = string * gtype;;
  type expression= Conjonction of expression * expression
		       | Comparaison of expression * expression
		       | Addition of expression * expression
		       | Variable of string;;
  type bloc = (declaration list)* (instruction list) 
  and instruction= Bloc of bloc | Affectation of string * expression;; 
# 28 "parser.ml"
let yytransl_const = [|
  257 (* BEGIN *);
  258 (* POINTVIRGULE *);
  259 (* AND *);
  260 (* END *);
  261 (* INT *);
  262 (* BOOL *);
  263 (* FLECHE *);
  264 (* PLUS *);
  265 (* PAROUV *);
  266 (* PARFERM *);
    0 (* EOF *);
  267 (* INF *);
  268 (* VIRGULE *);
    0|]

let yytransl_block = [|
  269 (* IDENT *);
    0|]

let yylhs = "\255\255\
\001\000\002\000\003\000\003\000\005\000\006\000\006\000\004\000\
\004\000\007\000\007\000\008\000\008\000\008\000\008\000\008\000\
\000\000"

let yylen = "\002\000\
\002\000\005\000\001\000\003\000\002\000\001\000\001\000\001\000\
\003\000\001\000\003\000\003\000\003\000\003\000\003\000\001\000\
\002\000"

let yydefred = "\000\000\
\000\000\000\000\000\000\017\000\000\000\006\000\007\000\000\000\
\000\000\000\000\001\000\000\000\000\000\005\000\000\000\010\000\
\000\000\000\000\004\000\000\000\002\000\000\000\000\000\016\000\
\000\000\009\000\000\000\000\000\000\000\000\000\015\000\000\000\
\012\000\000\000"

let yydgoto = "\002\000\
\004\000\016\000\008\000\017\000\009\000\010\000\018\000\025\000"

let yysindex = "\026\000\
\027\255\000\000\013\255\000\000\032\000\000\000\000\000\031\255\
\022\255\023\255\000\000\255\254\013\255\000\000\028\255\000\000\
\033\255\036\255\000\000\007\255\000\000\255\254\007\255\000\000\
\014\255\000\000\254\254\007\255\007\255\007\255\000\000\015\255\
\000\000\032\255"

let yyrindex = "\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\037\255\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\038\255\000\000\000\000\000\000\000\000\000\000\000\000\
\003\255\000\000\000\000\000\000\000\000\000\000\000\000\011\255\
\000\000\000\255"

let yygindex = "\000\000\
\000\000\040\000\030\000\022\000\000\000\000\000\000\000\001\000"

let yytablesize = 44
let yytable = "\003\000\
\028\000\013\000\013\000\013\000\011\000\029\000\011\000\031\000\
\030\000\013\000\013\000\015\000\014\000\014\000\014\000\023\000\
\028\000\006\000\007\000\024\000\014\000\029\000\029\000\027\000\
\030\000\030\000\001\000\003\000\032\000\033\000\034\000\011\000\
\012\000\013\000\020\000\014\000\021\000\022\000\003\000\029\000\
\005\000\008\000\019\000\026\000"

let yycheck = "\001\001\
\003\001\002\001\003\001\004\001\002\001\008\001\004\001\010\001\
\011\001\010\001\011\001\013\001\002\001\003\001\004\001\009\001\
\003\001\005\001\006\001\013\001\010\001\008\001\008\001\023\000\
\011\001\011\001\001\000\001\001\028\000\029\000\030\000\000\000\
\002\001\012\001\007\001\013\001\004\001\002\001\002\001\008\001\
\001\000\004\001\013\000\022\000"

let yynames_const = "\
  BEGIN\000\
  POINTVIRGULE\000\
  AND\000\
  END\000\
  INT\000\
  BOOL\000\
  FLECHE\000\
  PLUS\000\
  PAROUV\000\
  PARFERM\000\
  EOF\000\
  INF\000\
  VIRGULE\000\
  "

let yynames_block = "\
  IDENT\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'bloc) in
    Obj.repr(
# 52 "parser.mly"
          (_1 (*L'information interessante pour construire
 notre arbre abstrait se situe dans bloc*) )
# 131 "parser.ml"
               : bloc))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 3 : 'sdecl) in
    let _4 = (Parsing.peek_val __caml_parser_env 1 : 'sinst) in
    Obj.repr(
# 57 "parser.mly"
                                    ((_2,_4)
(*On construit le doublet (liste de déclarations,
liste d'arbres abstrait correspondant aux instructions) *))
# 141 "parser.ml"
               : 'bloc))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'decl) in
    Obj.repr(
# 63 "parser.mly"
      ([_1])
# 148 "parser.ml"
               : 'sdecl))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'decl) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'sdecl) in
    Obj.repr(
# 64 "parser.mly"
                      (_1::_3 
(*On construit la liste des declarations.*) )
# 157 "parser.ml"
               : 'sdecl))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'gtype) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 68 "parser.mly"
            ((_2,_1)
(*on récupère le type et le nom de l'ident, et on en fait un couple.*))
# 166 "parser.ml"
               : 'decl))
; (fun __caml_parser_env ->
    Obj.repr(
# 72 "parser.mly"
    (GINT)
# 172 "parser.ml"
               : 'gtype))
; (fun __caml_parser_env ->
    Obj.repr(
# 73 "parser.mly"
       (GBOOL)
# 178 "parser.ml"
               : 'gtype))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'inst) in
    Obj.repr(
# 76 "parser.mly"
      ([_1])
# 185 "parser.ml"
               : 'sinst))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'inst) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'sinst) in
    Obj.repr(
# 77 "parser.mly"
                          (_1::_3
(*on construit la liste des instructions.*))
# 194 "parser.ml"
               : 'sinst))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'bloc) in
    Obj.repr(
# 81 "parser.mly"
      (Bloc _1)
# 201 "parser.ml"
               : 'inst))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'expr) in
    Obj.repr(
# 82 "parser.mly"
                    (Affectation (_1,_3)
(*on créé l'arbre affectation récursivement avec l'ident et l'expression*))
# 210 "parser.ml"
               : 'inst))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'expr) in
    Obj.repr(
# 87 "parser.mly"
                (Addition (_1,_3))
# 218 "parser.ml"
               : 'expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'expr) in
    Obj.repr(
# 88 "parser.mly"
                (Comparaison(_1,_3))
# 226 "parser.ml"
               : 'expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'expr) in
    Obj.repr(
# 89 "parser.mly"
               (Conjonction (_1,_3))
# 234 "parser.ml"
               : 'expr))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'expr) in
    Obj.repr(
# 90 "parser.mly"
                      (_2)
# 241 "parser.ml"
               : 'expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 91 "parser.mly"
        (Variable _1)
# 248 "parser.ml"
               : 'expr))
(* Entry main *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
|]
let yytables =
  { Parsing.actions=yyact;
    Parsing.transl_const=yytransl_const;
    Parsing.transl_block=yytransl_block;
    Parsing.lhs=yylhs;
    Parsing.len=yylen;
    Parsing.defred=yydefred;
    Parsing.dgoto=yydgoto;
    Parsing.sindex=yysindex;
    Parsing.rindex=yyrindex;
    Parsing.gindex=yygindex;
    Parsing.tablesize=yytablesize;
    Parsing.table=yytable;
    Parsing.check=yycheck;
    Parsing.error_function=parse_error;
    Parsing.names_const=yynames_const;
    Parsing.names_block=yynames_block }
let main (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 1 lexfun lexbuf : bloc)
