(*TP n2 de compilation. BORDOZ Thomas, HARTUNIANS Sevan *)
(*  
Dans ce tp nous allons traiter les unit�s lexicales issues de l'analyse lexicale pour construire des arbres concrets et abstraits ainsi qu'une sequence d'unit� syntaxique.
De plus nous allons essayer de d�tecter un maximum d'erreurs syntaxiques.


PROBLEMES QUE NOUS AVONS RENCONTRES:
Nous n'avons pas r�ussi � utiliser la correction du tp1, donc nous utilisons notre version du tp1. De ce fait les arbre conditionnel sont g�n�r� "� la main".
*)
 


(*On r�utilise le type unit� l�xicale d�finie dans le tp1.*)
(*open Analex;;*)
#use "tp1.ml";;


(*On ouvre le module list utile pour d�finir des arbres syntaxique.*)
open List;;

(*On d�finit le type correspondant � un caract�re non terminal : vn.*)
type vn = S| EXPR | SUITEEXPR | TERMB | SUITETERMB | FACTEURB | RELATION | OP 
(*On d�finit le type correspondant � un caract�re terminal : vt.*)
type vt =  IDENT  | OU | ET | SI | ALORS | SINON | FSI | EOF | PAROUV | PARFERM | INFERIEUR | SUPERIEUR | EGAL |DIFFERENT
(*on d�finie le type caract�re de la grammaire*)
type v = VN of vn | VT of vt

(*Un arbre concret est un arbre n-aire dont les feuilles son des unit�s l�xicales et les noeuds des caract�res non terminaux.*)
type arbre_concret = FEUILLE of unite_lexicale | NOEUDS of  vn*(arbre_concret list)

(*exception que l'on l�ve si une unit� lexicale ne peut etre ransform� en caract�re de la grammaire*)
exception Pas_de_codage

(*fonction qui associe � une unit� lexicale un caract�re terminal. Leve une exception si l'unit� lexicale n'a pas de caract�re terminal associ�.*)
let codage = function

  UL_IDENT s -> IDENT
 | UL_PAROUV -> PAROUV
 | UL_PARFERM -> PARFERM
 | UL_OU  -> OU
 | UL_ET -> ET
 | UL_EOF -> EOF
 |  UL_SI -> SI
 | UL_ALORS ->ALORS
 | UL_SINON -> SINON
 | UL_FSI -> FSI
 |UL_INFERIEUR -> INFERIEUR
 | UL_SUPERIEUR -> SUPERIEUR
 | UL_EGAL -> EGAL
 | UL_DIFFERENT -> DIFFERENT
 | _ -> raise Pas_de_codage;;


(*exception que l'on l�ve si aucune derivation n'est possible*)
exception Pas_de_derivation of (vn*unite_lexicale);;



(* Fonction de d�rivation, qui � partir d'un caract�re non terminal et de la prochaine unit� lexicale lue dans la grammaire, rend une liste de caract�re
 (qui correspond � la partie droite de la d�rivation). *)
type derivation = vn*unite_lexicale->v list

let (ma_derivation : derivation) = function (vn1,ul1) ->
  (* Principe: On match le caract�re non terminal, d'apr�s la d�finition de notre grammaire,on match une des unit�s lexicales qui devrait se trouver apr�s ce caract�re. Enfin on l�ve une exception si
 l'unit� lexciale lue � la suite du caract�re ne correspond pas � notre grammaire.*)
 ( match vn1 with 
      S -> (match ul1 with UL_IDENT _ | UL_PAROUV | UL_SI -> (VN EXPR)::(VT EOF)::[] 
	      | _ ->raise (Pas_de_derivation (vn1,ul1)) )

    | EXPR ->(match ul1 with UL_IDENT _ | UL_PAROUV | UL_SI -> (VN TERMB)::(VN SUITEEXPR)::[]  
		| _ ->raise (Pas_de_derivation (vn1,ul1)))

    | SUITEEXPR -> (match ul1 with UL_OU -> (VT OU)::(VN TERMB)::(VN SUITEEXPR)::[]
		      | UL_PARFERM | UL_ALORS|UL_SINON|UL_FSI | UL_EOF -> []
		      | _ -> raise (Pas_de_derivation (vn1,ul1 )))

    | TERMB ->(match ul1 with UL_IDENT _ | UL_PAROUV | UL_SI -> (VN FACTEURB)::(VN SUITETERMB)::[] 
		 | _ ->raise (Pas_de_derivation (vn1,ul1)))

    | SUITETERMB -> (match ul1 with UL_ET -> (VT ET)::(VN FACTEURB)::(VN SUITETERMB)::[] 
		        |UL_ALORS | UL_PARFERM | UL_SINON | UL_FSI| UL_OU | UL_EOF -> []
		       | _ -> raise ( Pas_de_derivation (vn1,ul1)))

    | FACTEURB -> (match ul1 with (UL_IDENT _) -> [VN RELATION]
		                 | UL_PAROUV -> (VT PAROUV)::(VN EXPR)::(VT PARFERM)::[]
	                         | UL_SI -> (VT SI)::(VN EXPR)::(VT ALORS)::(VN EXPR)::(VT SINON)::(VN EXPR)::(VT FSI)::[] 
				 | _ -> raise (Pas_de_derivation (vn1,ul1)))

    | RELATION ->  (match ul1 with (UL_IDENT _) -> (VT IDENT)::(VN OP)::(VT IDENT)::[] 
		      | _ -> raise (Pas_de_derivation(vn1,ul1 )))
 
    | OP ->  (match ul1 with UL_EGAL -> [VT EGAL]    | UL_SUPERIEUR -> [VT SUPERIEUR]  | UL_INFERIEUR -> [VT INFERIEUR]  | UL_DIFFERENT -> [VT DIFFERENT] | _ -> raise (Pas_de_derivation(vn1,ul1 )) )

         ) ;; 


(*exception si l'unit� lexicale lue ne correspond pas au caract�re attendu*)
exception Ul_dif_du_carac of unite_lexicale;;

(*Definition de deux fonctions mutuellement r�cursives, qui � partir d'un caract�re et d'une liste d'unit� lexicale, construisent l'arbre syntaxique concret correspondant*)
(*analyse caract�re prend un caract�re et une liste d'unit�s lexicales et rend un arbre syntaxique*)
let rec analyse_caractere  v liste_uls derivation = 
  let ul_lue = hd liste_uls  in 
    match v with
	(*si le caract�re v est un terminal, on v�rifie que l'unit� lexicale en tete de liste est bien sa correspondante, sinon on l�ve une exception.
	 On cr�� l'arbre syntaxique r�duit � une feuille (� une unit� lexicale)*)
        VT t -> if t=(codage ul_lue)
	             then (FEUILLE ul_lue,(tl liste_uls) )  
	             else raise (Ul_dif_du_carac ul_lue)

	  (*si le caractere est non terminal, on cr�� un noeud ayant pour fils la liste d'arbre concret cr�� par analyse_mot*)
       | VN n ->let (liste_arbre,liste_ul) = analyse_mot (derivation (n,ul_lue)) liste_uls derivation in (NOEUDS (n,liste_arbre),liste_ul)
(*analyse mot prend une liste de caract�re et une liste d'unit�s lexicales et rend le couple (arbre concret correspondant*liste d'unit� lexicale restant � analyser)*)
and analyse_mot (mot : v list) liste_uls derivation =
  match mot with 
    (* cas: la liste de caract�re est  vide, on rend le couple (liste arbre vide*liste des unit�s lexicales inchang�s *)
    [] -> [],liste_uls

      (* cas liste non vide: pour chaque caract�re on l'analyse avec analyse caract�re *)
   | v::fin_mot -> let (arbre,liste_uls_restantes) = analyse_caractere v liste_uls derivation in
let (liste_arbres,liste_uls_restantes) = analyse_mot fin_mot liste_uls_restantes derivation in
((arbre::liste_arbres),liste_uls_restantes);;
 

(*Partie arbre abstrait*)

(*on d�fini un nouveau type op�rateur qu'on utilisera dans la construction de l'arbre abstrait*)
type op = Op_sup|Op_inf|Op_egal|Op_dif| Op_erreur;;

(*on d�fini un arbre abstrait r�cursivement comme:
- une comparaison entre deux chaines de caract�re
- ou une conjonction de deux arbres abstrait
- ou une disjonction de deux arbres abstrait 
- ou une condition repr�sent� par trois arbre abstrait*)
type arbre_abstrait = Comp of string*op*string 
| Conj of arbre_abstrait*arbre_abstrait
| Dijon of arbre_abstrait*arbre_abstrait
| Cond of arbre_abstrait*arbre_abstrait*arbre_abstrait


let codageOp = function
 UL_SUPERIEUR ->Op_sup
|UL_INFERIEUR -> Op_inf
|UL_EGAL ->Op_egal
|UL_DIFFERENT ->Op_dif
| _ -> Op_erreur



exception Construction_abstrait_impossible of (vn*arbre_concret list);;

(*Fonction de construction d'un arbre abstrait � partir d'un arbre concret, pass� en param�tre*)
let rec construit_arbre_abstrait = function NOEUDS(nt,l) ->
(*Principe: on trouve la r�gle de grammaire ou l'on se trouve en faisant un match sur le caract�re non terminal, on cr�� l'arbre abstrait correspondant(comp conj dij ou cond).
 On r�cup�re les �l�ments important en faisant une r�cursion sur les fils des noeuds (elements non terminaux),on ne garde que les op les ident et la structure.*) 
 ( match (nt,l) with
 S,l -> construit_arbre_abstrait(hd l)

| EXPR,[a;NOEUDS (SUITEEXPR,[])] -> construit_arbre_abstrait a

| EXPR,[a;NOEUDS(SUITEEXPR,[FEUILLE UL_OU;b;NOEUDS(SUITEEXPR,[])])] -> Dijon  ((construit_arbre_abstrait a),(construit_arbre_abstrait b))   

|TERMB,[a;NOEUDS(SUITETERMB, [])] -> construit_arbre_abstrait a

| TERMB,[a;NOEUDS(SUITETERMB,[FEUILLE UL_ET;b;NOEUDS(SUITETERMB,[])] )] -> Conj ((construit_arbre_abstrait a),(construit_arbre_abstrait b))


| FACTEURB,[NOEUDS(RELATION,[FEUILLE (UL_IDENT id1);NOEUDS (OP,[FEUILLE ope]);FEUILLE (UL_IDENT id2)])] -> Comp (id1,codageOp ope, id2)


| FACTEURB,[(FEUILLE UL_PAROUV);a;(FEUILLE UL_PARFERM)] -> (construit_arbre_abstrait a)
 
|FACTEURB,[FEUILLE UL_SI;a;FEUILLE UL_ALORS;b;FEUILLE UL_SINON;c;FEUILLE UL_FSI] -> Cond( (construit_arbre_abstrait a),(construit_arbre_abstrait b),(construit_arbre_abstrait c))  

| _ -> raise(Construction_abstrait_impossible(nt,l))
 );;
  
  
(************************* TEST DES FONCTIONS ************************************************)

(* Test de derivation *)
(* on met l'accent sur le test de cette fonction, car tout se base sur le fonctionnement de celle-ci*)
(*
  let valeur = ma_derivation (S,UL_IDENT "x");;   
let valeur = ma_derivation (S,UL_PAROUV);; 
let valeur = ma_derivation (S,UL_SI);;                       
let valeur = ma_derivation (S,UL_ET );; 
let valeur = ma_derivation (S,UL_OU );;
let valeur = ma_derivation (S,UL_EGAL );;

  val valeur : v list = [VN EXPR; VT EOF]
# val valeur : v list = [VN EXPR; VT EOF]
# val valeur : v list = [VN EXPR; VT EOF]
# Exception: Pas_de_derivation (S, UL_ET).
# Exception: Pas_de_derivation (S, UL_OU).
# Exception: Pas_de_derivation (S, UL_EGAL).
OK

let valeur = ma_derivation (EXPR,UL_IDENT "x");;   
let valeur = ma_derivation (EXPR,UL_PAROUV);; 
let valeur = ma_derivation (EXPR,UL_SI);;                       
let valeur = ma_derivation (EXPR,UL_ET );; 
let valeur = ma_derivation (EXPR,UL_OU );; 
let valeur = ma_derivation (EXPR,UL_EGAL );;

#   val valeur : v list = [VN TERMB; VN SUITEEXPR]
# val valeur : v list = [VN TERMB; VN SUITEEXPR]
# val valeur : v list = [VN TERMB; VN SUITEEXPR]
# Exception: Pas_de_derivation (EXPR, UL_ET).
# Exception: Pas_de_derivation (EXPR, UL_OU).
# Exception: Pas_de_derivation (EXPR, UL_EGAL).
OK

let valeur = ma_derivation (SUITEEXPR,UL_IDENT "x");;   
let valeur = ma_derivation (SUITEEXPR,UL_PAROUV);; 
let valeur = ma_derivation (SUITEEXPR,UL_SI);;                       
let valeur = ma_derivation (SUITEEXPR,UL_ET );; 
let valeur = ma_derivation (SUITEEXPR,UL_OU );; 
let valeur = ma_derivation (SUITEEXPR,UL_EGAL );;

#     Exception: Pas_de_derivation (SUITEEXPR, UL_IDENT "x").
# Exception: Pas_de_derivation (SUITEEXPR, UL_PAROUV).
# Exception: Pas_de_derivation (SUITEEXPR, UL_SI).
# Exception: Pas_de_derivation (SUITEEXPR, UL_ET).
# val valeur : v list = [VT OU; VN TERMB; VN SUITEEXPR]
# Exception: Pas_de_derivation (SUITEEXPR, UL_EGAL).
OK

let valeur = ma_derivation (TERMB,UL_IDENT "x");;   
let valeur = ma_derivation (TERMB,UL_PAROUV);; 
let valeur = ma_derivation (TERMB,UL_SI);;                       
let valeur = ma_derivation (TERMB,UL_ET );; 
let valeur = ma_derivation (TERMB,UL_OU );; 
let valeur = ma_derivation (TERMB,UL_EGAL );;
OK

#       val valeur : v list = [VN FACTEURB; VN SUITETERMB]
# val valeur : v list = [VN FACTEURB; VN SUITETERMB]
# val valeur : v list = [VN FACTEURB; VN SUITETERMB]
# Exception: Pas_de_derivation (TERMB, UL_ET).
# Exception: Pas_de_derivation (TERMB, UL_OU).
# Exception: Pas_de_derivation (TERMB, UL_EGAL).
OK

let valeur = ma_derivation (SUITETERMB,UL_IDENT "x");;   
let valeur = ma_derivation (SUITETERMB,UL_PAROUV);; 
let valeur = ma_derivation (SUITETERMB,UL_SI);;                       
let valeur = ma_derivation (SUITETERMB,UL_ET );; 
let valeur = ma_derivation (SUITETERMB,UL_OU );;
let valeur = ma_derivation (SUITETERMB,UL_EGAL );;

#     Exception: Pas_de_derivation (SUITETERMB, UL_IDENT "x").
# Exception: Pas_de_derivation (SUITETERMB, UL_PAROUV).
# Exception: Pas_de_derivation (SUITETERMB, UL_SI).
# val valeur : v list = [VT ET; VN FACTEURB; VN SUITETERMB]
# val valeur : v list = []
# Exception: Pas_de_derivation (SUITETERMB, UL_EGAL).
OK

let valeur = ma_derivation (FACTEURB,UL_IDENT "x");;   
let valeur = ma_derivation (FACTEURB,UL_PAROUV);; 
let valeur = ma_derivation (FACTEURB,UL_SI);;                       
let valeur = ma_derivation (FACTEURB,UL_ET );; 
let valeur = ma_derivation (FACTEURB,UL_OU );;
let valeur = ma_derivation (FACTEURB,UL_EGAL );;

#       val valeur : v list = [VN RELATION]
# val valeur : v list = [VT PAROUV; VN EXPR; VT PARFERM]
# val valeur : v list =
  [VT SI; VN EXPR; VT ALORS; VN EXPR; VT SINON; VN EXPR; VT FSI]
# Exception: Pas_de_derivation (FACTEURB, UL_ET).
# Exception: Pas_de_derivation (FACTEURB, UL_OU).
# Exception: Pas_de_derivation (FACTEURB, UL_EGAL).
OK

let valeur = ma_derivation (RELATION,UL_IDENT "x");;   
let valeur = ma_derivation (RELATION,UL_PAROUV);; 
let valeur = ma_derivation (RELATION,UL_SI);;                       
let valeur = ma_derivation (RELATION,UL_ET );; 
let valeur = ma_derivation (RELATION,UL_OU );;
let valeur = ma_derivation (RELATION,UL_EGAL );;

#       val valeur : v list = [VT IDENT; VN OP; VT IDENT]
# Exception: Pas_de_derivation (RELATION, UL_PAROUV).
# Exception: Pas_de_derivation (RELATION, UL_SI).
# Exception: Pas_de_derivation (RELATION, UL_ET).
# Exception: Pas_de_derivation (RELATION, UL_OU).
# Exception: Pas_de_derivation (RELATION, UL_EGAL).
OK
*)

(*
DERIVATION DONNE TOUT LES RESULTATS ATTENDUES.

 DANS LA SUITE DES TEST, ON NE TESTERA PAS TOUT LES CAS, ON ADMETTRA: SI LA FONCTION FONCTIONNE POUR QUELQUES CAS, QUEL UTILISE DERIVATION, ALORS ELLE MARCHE DANS TOUT LES CAS. *)
(* fin de test de derivation*)

(* deux fonctions pour recupere les unites lexicales et les arbres en singleton*)
let rec construit_liste_uls = function 
    (ul,lex)::r -> ul::(construit_liste_uls r)
  | [] -> [];;


let recuperer_ac = function (arbre::[],[]) -> arbre

 

(************** TEST 1*******************)
(* test simple qui reste relation les parentheses et la conjonction.
let test = open_in "test.ml";;
let liste_unites_lexicale_test = construit_liste_uls (scanner test mon_automate) ;;
let arbre_conc = analyse_mot [VN S] liste_unites_lexicale_test ma_derivation;;
let arbre_abstr = construit_arbre_abstrait (recuperer_ac arbre_conc);;

# val liste_unites_lexicale_test : unite_lexicale list =
  [UL_PAROUV; UL_IDENT "z2"; UL_INFERIEUR; UL_IDENT "z1"; UL_PARFERM; UL_ET;
   UL_PAROUV; UL_IDENT "z2"; UL_INFERIEUR; UL_IDENT "z1"; UL_PARFERM; UL_EOF]
# val arbre_conc : arbre_concret list * unite_lexicale list =
  ([NOEUDS (S,
     [NOEUDS (EXPR,
       [NOEUDS (TERMB,
         [NOEUDS (FACTEURB,
           [FEUILLE UL_PAROUV;
            NOEUDS (EXPR,
             [NOEUDS (TERMB,
               [NOEUDS (FACTEURB,
                 [NOEUDS (RELATION,
                   [FEUILLE (UL_IDENT "z2");
                    NOEUDS (OP, [FEUILLE UL_INFERIEUR]);
                    FEUILLE (UL_IDENT "z1")])]);
                NOEUDS (SUITETERMB, [])]);
              NOEUDS (SUITEEXPR, [])]);
            FEUILLE UL_PARFERM]);
          NOEUDS (SUITETERMB,
           [FEUILLE UL_ET;
            NOEUDS (FACTEURB,
             [FEUILLE UL_PAROUV;
              NOEUDS (EXPR,
               [NOEUDS (TERMB,
                 [NOEUDS (FACTEURB,
                   [NOEUDS (RELATION,
                     [FEUILLE (UL_IDENT "z2");
                      NOEUDS (OP, [FEUILLE UL_INFERIEUR]);
                      FEUILLE (UL_IDENT "z1")])]);
                  NOEUDS (SUITETERMB, [])]);
                NOEUDS (SUITEEXPR, [])]);
              FEUILLE UL_PARFERM]);
            NOEUDS (SUITETERMB, [])])]);
        NOEUDS (SUITEEXPR, [])]);
      FEUILLE UL_EOF])],
   [])
# val arbre_abstr : arbre_abstrait =
  Conj (Comp ("z2", Op_inf, "z1"), Comp ("z2", Op_inf, "z1"))
   
   Le r�sultat du test est bien celui attendu.
  
  *************************************TEST 2*******************)
(*
 test tr�s simple r�duis � une relation. L'arbre abstrait et l'arbre concret sont correctements cr��.
 
let liste_unites_lexicale_test2 = [UL_IDENT "x2"; UL_EGAL; UL_IDENT "y3"; UL_EOF]
let arbre_conc2 = analyse_mot [VN S] liste_unites_lexicale_test2 ma_derivation;;
let arbre_abstr = construit_arbre_abstrait (recuperer_ac arbre_conc2);;


#           *             val liste_unites_lexicale_test2 : unite_lexicale list =
  [UL_IDENT "x2"; UL_EGAL; UL_IDENT "y3"; UL_EOF]
val arbre_conc2 : arbre_concret list * unite_lexicale list =
  ([NOEUDS (S,
     [NOEUDS (EXPR,
       [NOEUDS (TERMB,
         [NOEUDS (FACTEURB,
           [NOEUDS (RELATION,
             [FEUILLE (UL_IDENT "x2"); NOEUDS (OP, [FEUILLE UL_EGAL]);
              FEUILLE (UL_IDENT "y3")])]);
          NOEUDS (SUITETERMB, [])]);
        NOEUDS (SUITEEXPR, [])]);
      FEUILLE UL_EOF])],
   [])
# val arbre_abstr : arbre_abstrait = Comp ("x2", Op_egal, "y3")

   Le r�sultat du test est bien celui attendu.


(*****************************TEST 3*********************************************)
let test3 = open_in "test3.ml";;
let liste_unites_lexicale_test3 =  construit_liste_uls (scanner test3 mon_automate) ;;
let arbre_conc3 = analyse_mot [VN S] liste_unites_lexicale_test3 ma_derivation;;
let arbre_abstr = construit_arbre_abstrait (recuperer_ac arbre_conc3);;


(*            Test utilisant toute la grammaire, sauf la conditionnel. *)
   
#             val test3 : in_channel = <abstr>
# val liste_unites_lexicale_test3 : unite_lexicale list =
  [UL_IDENT "x1"; UL_INFERIEUR; UL_IDENT "y1"; UL_ET; UL_PAROUV;
   UL_IDENT "a4"; UL_EGAL; UL_IDENT "p5"; UL_OU; UL_IDENT "truc";
   UL_SUPERIEUR; UL_IDENT "truc"; UL_PARFERM; UL_EOF]
# val arbre_conc3 : arbre_concret list * unite_lexicale list =
  ([NOEUDS (S,
     [NOEUDS (EXPR,
       [NOEUDS (TERMB,
         [NOEUDS (FACTEURB,
           [NOEUDS (RELATION,
             [FEUILLE (UL_IDENT "x1"); NOEUDS (OP, [FEUILLE UL_INFERIEUR]);
              FEUILLE (UL_IDENT "y1")])]);
          NOEUDS (SUITETERMB,
           [FEUILLE UL_ET;
            NOEUDS (FACTEURB,
             [FEUILLE UL_PAROUV;
              NOEUDS (EXPR,
               [NOEUDS (TERMB,
                 [NOEUDS (FACTEURB,
                   [NOEUDS (RELATION,
                     [FEUILLE (UL_IDENT "a4");
                      NOEUDS (OP, [FEUILLE UL_EGAL]);
                      FEUILLE (UL_IDENT "p5")])]);
                  NOEUDS (SUITETERMB, [])]);
                NOEUDS (SUITEEXPR,
                 [FEUILLE UL_OU;
                  NOEUDS (TERMB,
                   [NOEUDS (FACTEURB,
                     [NOEUDS (RELATION,
                       [FEUILLE (UL_IDENT "truc");
                        NOEUDS (OP, [FEUILLE UL_SUPERIEUR]);
                        FEUILLE (UL_IDENT "truc")])]);
                    NOEUDS (SUITETERMB, [])]);
                  NOEUDS (SUITEEXPR, [])])]);
              FEUILLE UL_PARFERM]);
            NOEUDS (SUITETERMB, [])])]);
        NOEUDS (SUITEEXPR, [])]);
      FEUILLE UL_EOF])],
   [])
# val arbre_abstr : arbre_abstrait =
  Conj (Comp ("x1", Op_inf, "y1"),
   Dijon (Comp ("a4", Op_egal, "p5"), Comp ("truc", Op_sup, "truc")))
   
   (* r�sultats satisfaisants.*)
   
   
(************************************ TEST 4 ***********************************)


let liste_unites_lexicale_test4 = [UL_SI;UL_IDENT "x2"; UL_EGAL; UL_IDENT "y3";UL_ALORS;UL_IDENT "x2"; UL_EGAL; UL_IDENT "y3";UL_SINON;UL_IDENT "x2"; UL_EGAL; UL_IDENT "y3";UL_FSI; UL_EOF]
let arbre_conc4 = analyse_mot [VN S] liste_unites_lexicale_test4 ma_derivation;;
let arbre_abstr = construit_arbre_abstrait (recuperer_ac arbre_conc4);;

(* Test de la conditionnelle. .*)
   
#                 val liste_unites_lexicale_test4 : unite_lexicale list =
  [UL_SI; UL_IDENT "x2"; UL_EGAL; UL_IDENT "y3"; UL_ALORS; UL_IDENT "x2";
   UL_EGAL; UL_IDENT "y3"; UL_SINON; UL_IDENT "x2"; UL_EGAL; UL_IDENT "y3";
   UL_FSI; UL_EOF]
val arbre_conc4 : arbre_concret list * unite_lexicale list =
  ([NOEUDS (S,
     [NOEUDS (EXPR,
       [NOEUDS (TERMB,
         [NOEUDS (FACTEURB,
           [FEUILLE UL_SI;
            NOEUDS (EXPR,
             [NOEUDS (TERMB,
               [NOEUDS (FACTEURB,
                 [NOEUDS (RELATION,
                   [FEUILLE (UL_IDENT "x2"); NOEUDS (OP, [FEUILLE UL_EGAL]);
                    FEUILLE (UL_IDENT "y3")])]);
                NOEUDS (SUITETERMB, [])]);
              NOEUDS (SUITEEXPR, [])]);
            FEUILLE UL_ALORS;
            NOEUDS (EXPR,
             [NOEUDS (TERMB,
               [NOEUDS (FACTEURB,
                 [NOEUDS (RELATION,
                   [FEUILLE (UL_IDENT "x2"); NOEUDS (OP, [FEUILLE UL_EGAL]);
                    FEUILLE (UL_IDENT "y3")])]);
                NOEUDS (SUITETERMB, [])]);
              NOEUDS (SUITEEXPR, [])]);
            FEUILLE UL_SINON;
            NOEUDS (EXPR,
             [NOEUDS (TERMB,
               [NOEUDS (FACTEURB,
                 [NOEUDS (RELATION,
                   [FEUILLE (UL_IDENT "x2"); NOEUDS (OP, [FEUILLE UL_EGAL]);
                    FEUILLE (UL_IDENT "y3")])]);
                NOEUDS (SUITETERMB, [])]);
              NOEUDS (SUITEEXPR, [])]);
            FEUILLE UL_FSI]);
          NOEUDS (SUITETERMB, [])]);
        NOEUDS (SUITEEXPR, [])]);
      FEUILLE UL_EOF])],
   [])
# val arbre_abstr : arbre_abstrait =
  Cond (Comp ("x2", Op_egal, "y3"), Comp ("x2", Op_egal, "y3"),
   Comp ("x2", Op_egal, "y3"))
   
   Les deux arbres sont corrects
   
   (***********************************TEST5 ************************)

(*test de la conjonction*)

let test = open_in "test4.ml";;
let liste_unites_lexicale_test = construit_liste_uls (scanner test mon_automate) ;;
let arbre_conc = analyse_mot [VN S] liste_unites_lexicale_test ma_derivation;;
let arbre_abstr = construit_arbre_abstrait (recuperer_ac arbre_conc);;

   
#             val test : in_channel = <abstr>
# val liste_unites_lexicale_test : unite_lexicale list =
  [UL_PAROUV; UL_IDENT "z2"; UL_INFERIEUR; UL_IDENT "z1"; UL_PARFERM; UL_OU;
   UL_PAROUV; UL_IDENT "z2"; UL_INFERIEUR; UL_IDENT "z1"; UL_PARFERM; UL_EOF]
# val arbre_conc : arbre_concret list * unite_lexicale list =
  ([NOEUDS (S,
     [NOEUDS (EXPR,
       [NOEUDS (TERMB,
         [NOEUDS (FACTEURB,
           [FEUILLE UL_PAROUV;
            NOEUDS (EXPR,
             [NOEUDS (TERMB,
               [NOEUDS (FACTEURB,
                 [NOEUDS (RELATION,
                   [FEUILLE (UL_IDENT "z2");
                    NOEUDS (OP, [FEUILLE UL_INFERIEUR]);
                    FEUILLE (UL_IDENT "z1")])]);
                NOEUDS (SUITETERMB, [])]);
              NOEUDS (SUITEEXPR, [])]);
            FEUILLE UL_PARFERM]);
          NOEUDS (SUITETERMB, [])]);
        NOEUDS (SUITEEXPR,
         [FEUILLE UL_OU;
          NOEUDS (TERMB,
           [NOEUDS (FACTEURB,
             [FEUILLE UL_PAROUV;
              NOEUDS (EXPR,
               [NOEUDS (TERMB,
                 [NOEUDS (FACTEURB,
                   [NOEUDS (RELATION,
                     [FEUILLE (UL_IDENT "z2");
                      NOEUDS (OP, [FEUILLE UL_INFERIEUR]);
                      FEUILLE (UL_IDENT "z1")])]);
                  NOEUDS (SUITETERMB, [])]);
                NOEUDS (SUITEEXPR, [])]);
              FEUILLE UL_PARFERM]);
            NOEUDS (SUITETERMB, [])]);
          NOEUDS (SUITEEXPR, [])])]);
      FEUILLE UL_EOF])],
   [])
# val arbre_abstr : arbre_abstrait =
  Dijon (Comp ("z2", Op_inf, "z1"), Comp ("z2", Op_inf, "z1"))AT TEST 1*************************)


(* Arbres OK*)

(*CONCLUSIONS DES TEST*)

(*Aucun bug na �t� retennu dans ces test assez exhausifs, les arbres concrets et abstraits se construisent parfaitement.*)

(**************************FIN DES TEST ******************************************************)


(***************** REPONSES AUX QUESTIONS *****************************************************)
(*
Grammaire:

S -> EXPR $
EXPR -> TERMB SUITEEXPR
SUITEEXPR -> ou TERMB SUITEEXPR | Epsilon
TERMB -> FACTEURB SUITETERMB 
SUITETERMB -> et FACTEURB SUITETERMB | Epsilon
FACTEURB -> RELATION | ( EXPR ) | si EXPR alors EXPR sinon EXPR fsi
RELATION -> ident op ident

Pour v�rifier que la grammaire est LL(1) on utilise le th�or�me:
1) premier(ai)inter premier(aj) = vide
2) null(A) => premier(A)inter suivant(A) = vide
3) null(A) => il esxiste un unique i tel que null(ai)

Les points 1 et 3 se v�rifie facilement en voyant la grammaire

v�rification du point 2)
on a null(SUITEEXPR) et null(SUITETERMN)

premier(SUITEEXPR) = ou
suivant(SUITEEXPR) = $,),alors,sinon,fsi
=> l'intersection de premier est suivant est nulle, OK

premier(SUITETERMB) = et
suivant(SUITETERMB) = $,),alors,sinon,fsi
=> l'intersection de premier est suivant est nulle, donc le langage est LL(1)


Question 2.1) 

On n'inclus pas les commentaires car le langage est construit � partir d'unit� lexicales, donc ceux ci on d�j� �t� enlev� par l'analyseur lexical.

Question 2.2) 

On n'a pas besoin d'utiliser un automate � pile (que l'on d�fini), en fait on utilise implicitement la pile de caml.

Question 2.3)

On utilise une grammaire LL(1) car cette grammaire garanti un arbre syntaxique concret unique.
 De plus le parseur LL(1) a comme principale avantage d'�tre simple � impl�menter Il est �galement tr�s rapide.

Question 2.4)

L'arbre abstrait permet de se d�barasser des �l�ments superflus( parenth�ses, et, ou , si, sinon, fsi) qui ne servent qu'� une meilleure lecture  du programme.
Sans perdre d'information, c'est l'arbre qui contient toute l'information utile du programme.

*)
