(*TP1 COMPILATION LSR G1
HARTUNIANS Sevan
BORDOZ Thomas
*)

(*Definitions des types ETAT, LEXEME, TRANSITION et DES TYPES DE CARACTERES*)
type etat = Qi | Qident | Qfcons | Qfnoncons | Qop | Qcom | Qeof |Qdebcom | Qfincom | Qerreur
type carac = BLANC | SLASH | LETTRE | CHIFFRE | OP | EOF | ETOILE |PARENTHESE | AUTRE

type lexeme = string
type transitions = etat -> carac -> etat
exception Pas_de_transition of etat*carac


(* Renvoie le type du charactere passe en parametre*)
let (type_carac: char -> carac) = function
      ' ' | '\n' | '\t' -> BLANC
      | '\000' -> EOF
      | '*' -> ETOILE
      | '/' -> SLASH
      | '0'..'9' -> CHIFFRE
      | 'a'..'z'  | 'A'..'Z' -> LETTRE
      | '(' | ')' -> PARENTHESE
      | '=' | '<' | '>' -> OP
      | _ -> AUTRE
      


(*Def du type automate*)
type automate = {
 init: etat;
 final_cons: etat;
 final_non_cons: etat;
transitions: transitions;
}

(*Fonction de transition correspondant à la grammaire associe*)
let (mes_transitions: transitions) = fun e c-> match e with
 Qi -> (match c with 
	    BLANC -> Qi
	  | LETTRE -> Qident
	  |PARENTHESE -> Qfcons
	  |OP -> Qop
	  |SLASH -> Qdebcom
	  |EOF -> Qeof 
          | _ -> raise (Pas_de_transition(e,c))
       )
  | Qident -> (match c with
                 LETTRE -> Qident
		 |CHIFFRE -> Qident
		 | _ -> Qfnoncons
	      )
  | Qop -> (match c with
		OP -> Qop
	      | _ -> Qfnoncons )
  | Qdebcom -> (match c with 
		    ETOILE -> Qcom
		  | _ -> raise  (Pas_de_transition(e,c))
)
   |Qcom -> (match c with
		 EOF -> Qeof
	       |ETOILE -> Qfincom
	       | _ -> Qcom
	    )
   | Qfincom -> (match c with 
		    ETOILE -> Qfincom
		   |EOF -> Qeof
		   | SLASH -> Qi
		   | _ -> Qcom
		)
    | _ -> raise  (Pas_de_transition(e,c))
   

(* On cree un Objet automate avec pour parametres la fct de transition ci dessus*)
let (mon_automate: automate)= {
init = Qi;
final_cons = Qfcons;
final_non_cons = Qfcons;
transitions = mes_transitions
}




(*fichier d'entree-> mon_automate->etat courant -> chaine courante -> (etat final, chaine lue)
Fonction de parcours de l'automate qui renvoie l'etat final et le lexeme associé.
*)
let rec(parcours_automate: in_channel->automate->etat-> string-> (etat*lexeme)) = fun c a e s ->
 let carLu = (try (input_char c) with End_of_file -> '\000') in
 let car = type_carac carLu in
    let nouvel_etat =(try mes_transitions e car with (Pas_de_transition (et,ca)) -> Qerreur ) in  
      match nouvel_etat with 
	 Qi -> parcours_automate c a nouvel_etat ""
	|Qfcons -> (Qfcons,(s ^ (String.make 1 carLu)))
	|Qfnoncons -> (seek_in c ((pos_in c)-1)); (Qfnoncons,s)
	|Qeof -> (Qeof,s)
	|Qerreur -> (e,s^(String.make 1 carLu))
	|_ -> parcours_automate c a nouvel_etat (s ^(String.make 1 carLu) )   

(*Definition des unites lexicales utilisées dans ce programme*)
type unite_lexicale= UL_IDENT of string | UL_PAROUV | UL_PARFERM | UL_EGAL | UL_DIFFERENT | UL_INFERIEUR | UL_SUPERIEUR | UL_OU | UL_ET | UL_EOF | UL_ERR of string | UL_SI | UL_ALORS | UL_SINON | UL_FSI|UL_SUPEGAL
|UL_INFEGAL

(*Definition du type du crible*)
type crible= lexeme->etat -> unite_lexicale
(*Une grammaire est composé d'un automate et d'un crible*)
type grammaire = {
automate: automate;
crible: crible;
};;


(*Fonction du crible qui prend un string et un état et renvoit l'unite lexicale associée*)
let (mon_crible: crible)= fun s e ->
  match e with 
Qeof -> UL_EOF
   | _ -> ( match s with
	"(" -> UL_PAROUV
       | ")" -> UL_PARFERM
       | "=" -> UL_EGAL
       | "<>" ->UL_DIFFERENT
       | "<" -> UL_INFERIEUR
       | ">" -> UL_SUPERIEUR
       |"si" -> UL_SI
       | "alors" -> UL_ALORS
       | "sinon" -> UL_SINON 
       | "fsi" -> UL_FSI
       | "ou" -> UL_OU
       | "et" -> UL_ET
       | _ ->( match type_carac (String.get s 0) with 
	     LETTRE -> UL_IDENT s
	   | _ -> UL_ERR s
		    )
	  )	  
(*Fonction qui prend un fichier et un automate et qui renvoit un couple (unite_lexicale, lexeme) *)
let (get_token: in_channel -> automate->unite_lexicale*lexeme) = fun c a ->
 let (et,lex) = parcours_automate  c  a a.init "" in
(mon_crible lex et,lex)

(*Fonction qui permet de scanner un fichier et de retourner tout les couples (unite_lexicale,lexeme) du fichier en entree*)
let rec (scanner: in_channel -> automate -> (unite_lexicale*lexeme)list) = 
function c -> function a ->
  let (unit,lex) = get_token c a in
    if (unit = UL_EOF) 
    then  (UL_EOF,"")::[]
    else (unit,lex)::(scanner c a)

(*
(*Permet de charger et scanner le fichier test
Procedure de test automatique *)
let (mon_chan:in_channel) = open_in "test";;
scanner mon_chan mon_automate;;

*)

