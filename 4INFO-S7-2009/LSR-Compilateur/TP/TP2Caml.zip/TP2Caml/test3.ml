x1 < y1 et ( a4 = p5 ou truc > truc)
