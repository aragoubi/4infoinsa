(************** TEST 1*******************)
(* test simple qui reste relation les parentheses et la conjonction.
let test = open_in "test.ml";;
let liste_unites_lexicale_test = construit_liste_uls (scanner test mon_automate) ;;
let arbre_conc = analyse_mot [VN S] liste_unites_lexicale_test ma_derivation;;
let arbre_abstr = construit_arbre_abstrait (recuperer_ac arbre_conc);;

# val liste_unites_lexicale_test : unite_lexicale list =
  [UL_PAROUV; UL_IDENT "z2"; UL_INFERIEUR; UL_IDENT "z1"; UL_PARFERM; UL_ET;
   UL_PAROUV; UL_IDENT "z2"; UL_INFERIEUR; UL_IDENT "z1"; UL_PARFERM; UL_EOF]
# val arbre_conc : arbre_concret list * unite_lexicale list =
  ([NOEUDS (S,
     [NOEUDS (EXPR,
       [NOEUDS (TERMB,
         [NOEUDS (FACTEURB,
           [FEUILLE UL_PAROUV;
            NOEUDS (EXPR,
             [NOEUDS (TERMB,
               [NOEUDS (FACTEURB,
                 [NOEUDS (RELATION,
                   [FEUILLE (UL_IDENT "z2");
                    NOEUDS (OP, [FEUILLE UL_INFERIEUR]);
                    FEUILLE (UL_IDENT "z1")])]);
                NOEUDS (SUITETERMB, [])]);
              NOEUDS (SUITEEXPR, [])]);
            FEUILLE UL_PARFERM]);
          NOEUDS (SUITETERMB,
           [FEUILLE UL_ET;
            NOEUDS (FACTEURB,
             [FEUILLE UL_PAROUV;
              NOEUDS (EXPR,
               [NOEUDS (TERMB,
                 [NOEUDS (FACTEURB,
                   [NOEUDS (RELATION,
                     [FEUILLE (UL_IDENT "z2");
                      NOEUDS (OP, [FEUILLE UL_INFERIEUR]);
                      FEUILLE (UL_IDENT "z1")])]);
                  NOEUDS (SUITETERMB, [])]);
                NOEUDS (SUITEEXPR, [])]);
              FEUILLE UL_PARFERM]);
            NOEUDS (SUITETERMB, [])])]);
        NOEUDS (SUITEEXPR, [])]);
      FEUILLE UL_EOF])],
   [])
# val arbre_abstr : arbre_abstrait =
  Conj (Comp ("z2", Op_inf, "z1"), Comp ("z2", Op_inf, "z1"))
   
   Le r�sultat du test est bien celui attendu.
  
  *************************************TEST 2*******************)
(*
 test tr�s simple r�duis � une relation. L'arbre abstrait et l'arbre concret sont correctements cr��.
 
let liste_unites_lexicale_test2 = [UL_IDENT "x2"; UL_EGAL; UL_IDENT "y3"; UL_EOF]
let arbre_conc2 = analyse_mot [VN S] liste_unites_lexicale_test2 ma_derivation;;
let arbre_abstr = construit_arbre_abstrait (recuperer_ac arbre_conc2);;


#           *             val liste_unites_lexicale_test2 : unite_lexicale list =
  [UL_IDENT "x2"; UL_EGAL; UL_IDENT "y3"; UL_EOF]
val arbre_conc2 : arbre_concret list * unite_lexicale list =
  ([NOEUDS (S,
     [NOEUDS (EXPR,
       [NOEUDS (TERMB,
         [NOEUDS (FACTEURB,
           [NOEUDS (RELATION,
             [FEUILLE (UL_IDENT "x2"); NOEUDS (OP, [FEUILLE UL_EGAL]);
              FEUILLE (UL_IDENT "y3")])]);
          NOEUDS (SUITETERMB, [])]);
        NOEUDS (SUITEEXPR, [])]);
      FEUILLE UL_EOF])],
   [])
# val arbre_abstr : arbre_abstrait = Comp ("x2", Op_egal, "y3")

   Le r�sultat du test est bien celui attendu.


(*****************************TEST 3*********************************************)
let test3 = open_in "test3.ml";;
let liste_unites_lexicale_test3 =  construit_liste_uls (scanner test3 mon_automate) ;;
let arbre_conc3 = analyse_mot [VN S] liste_unites_lexicale_test3 ma_derivation;;
let arbre_abstr = construit_arbre_abstrait (recuperer_ac arbre_conc3);;


(*            Test utilisant toute la grammaire, sauf la conditionnel. *)
   
#             val test3 : in_channel = <abstr>
# val liste_unites_lexicale_test3 : unite_lexicale list =
  [UL_IDENT "x1"; UL_INFERIEUR; UL_IDENT "y1"; UL_ET; UL_PAROUV;
   UL_IDENT "a4"; UL_EGAL; UL_IDENT "p5"; UL_OU; UL_IDENT "truc";
   UL_SUPERIEUR; UL_IDENT "truc"; UL_PARFERM; UL_EOF]
# val arbre_conc3 : arbre_concret list * unite_lexicale list =
  ([NOEUDS (S,
     [NOEUDS (EXPR,
       [NOEUDS (TERMB,
         [NOEUDS (FACTEURB,
           [NOEUDS (RELATION,
             [FEUILLE (UL_IDENT "x1"); NOEUDS (OP, [FEUILLE UL_INFERIEUR]);
              FEUILLE (UL_IDENT "y1")])]);
          NOEUDS (SUITETERMB,
           [FEUILLE UL_ET;
            NOEUDS (FACTEURB,
             [FEUILLE UL_PAROUV;
              NOEUDS (EXPR,
               [NOEUDS (TERMB,
                 [NOEUDS (FACTEURB,
                   [NOEUDS (RELATION,
                     [FEUILLE (UL_IDENT "a4");
                      NOEUDS (OP, [FEUILLE UL_EGAL]);
                      FEUILLE (UL_IDENT "p5")])]);
                  NOEUDS (SUITETERMB, [])]);
                NOEUDS (SUITEEXPR,
                 [FEUILLE UL_OU;
                  NOEUDS (TERMB,
                   [NOEUDS (FACTEURB,
                     [NOEUDS (RELATION,
                       [FEUILLE (UL_IDENT "truc");
                        NOEUDS (OP, [FEUILLE UL_SUPERIEUR]);
                        FEUILLE (UL_IDENT "truc")])]);
                    NOEUDS (SUITETERMB, [])]);
                  NOEUDS (SUITEEXPR, [])])]);
              FEUILLE UL_PARFERM]);
            NOEUDS (SUITETERMB, [])])]);
        NOEUDS (SUITEEXPR, [])]);
      FEUILLE UL_EOF])],
   [])
# val arbre_abstr : arbre_abstrait =
  Conj (Comp ("x1", Op_inf, "y1"),
   Dijon (Comp ("a4", Op_egal, "p5"), Comp ("truc", Op_sup, "truc")))
   
   (* r�sultats satisfaisants.*)
   
   
(************************************ TEST 4 ***********************************)


let liste_unites_lexicale_test4 = [UL_SI;UL_IDENT "x2"; UL_EGAL; UL_IDENT "y3";UL_ALORS;UL_IDENT "x2"; UL_EGAL; UL_IDENT "y3";UL_SINON;UL_IDENT "x2"; UL_EGAL; UL_IDENT "y3";UL_FSI; UL_EOF]
let arbre_conc4 = analyse_mot [VN S] liste_unites_lexicale_test4 ma_derivation;;
let arbre_abstr = construit_arbre_abstrait (recuperer_ac arbre_conc4);;

(* Test de la conditionnelle. .*)
   
#                 val liste_unites_lexicale_test4 : unite_lexicale list =
  [UL_SI; UL_IDENT "x2"; UL_EGAL; UL_IDENT "y3"; UL_ALORS; UL_IDENT "x2";
   UL_EGAL; UL_IDENT "y3"; UL_SINON; UL_IDENT "x2"; UL_EGAL; UL_IDENT "y3";
   UL_FSI; UL_EOF]
val arbre_conc4 : arbre_concret list * unite_lexicale list =
  ([NOEUDS (S,
     [NOEUDS (EXPR,
       [NOEUDS (TERMB,
         [NOEUDS (FACTEURB,
           [FEUILLE UL_SI;
            NOEUDS (EXPR,
             [NOEUDS (TERMB,
               [NOEUDS (FACTEURB,
                 [NOEUDS (RELATION,
                   [FEUILLE (UL_IDENT "x2"); NOEUDS (OP, [FEUILLE UL_EGAL]);
                    FEUILLE (UL_IDENT "y3")])]);
                NOEUDS (SUITETERMB, [])]);
              NOEUDS (SUITEEXPR, [])]);
            FEUILLE UL_ALORS;
            NOEUDS (EXPR,
             [NOEUDS (TERMB,
               [NOEUDS (FACTEURB,
                 [NOEUDS (RELATION,
                   [FEUILLE (UL_IDENT "x2"); NOEUDS (OP, [FEUILLE UL_EGAL]);
                    FEUILLE (UL_IDENT "y3")])]);
                NOEUDS (SUITETERMB, [])]);
              NOEUDS (SUITEEXPR, [])]);
            FEUILLE UL_SINON;
            NOEUDS (EXPR,
             [NOEUDS (TERMB,
               [NOEUDS (FACTEURB,
                 [NOEUDS (RELATION,
                   [FEUILLE (UL_IDENT "x2"); NOEUDS (OP, [FEUILLE UL_EGAL]);
                    FEUILLE (UL_IDENT "y3")])]);
                NOEUDS (SUITETERMB, [])]);
              NOEUDS (SUITEEXPR, [])]);
            FEUILLE UL_FSI]);
          NOEUDS (SUITETERMB, [])]);
        NOEUDS (SUITEEXPR, [])]);
      FEUILLE UL_EOF])],
   [])
# val arbre_abstr : arbre_abstrait =
  Cond (Comp ("x2", Op_egal, "y3"), Comp ("x2", Op_egal, "y3"),
   Comp ("x2", Op_egal, "y3"))
   
   Les deux arbres sont corrects
   
   (***********************************TEST5 ************************)

(*test de la conjonction*)

let test = open_in "test4.ml";;
let liste_unites_lexicale_test = construit_liste_uls (scanner test mon_automate) ;;
let arbre_conc = analyse_mot [VN S] liste_unites_lexicale_test ma_derivation;;
let arbre_abstr = construit_arbre_abstrait (recuperer_ac arbre_conc);;

   
#             val test : in_channel = <abstr>
# val liste_unites_lexicale_test : unite_lexicale list =
  [UL_PAROUV; UL_IDENT "z2"; UL_INFERIEUR; UL_IDENT "z1"; UL_PARFERM; UL_OU;
   UL_PAROUV; UL_IDENT "z2"; UL_INFERIEUR; UL_IDENT "z1"; UL_PARFERM; UL_EOF]
# val arbre_conc : arbre_concret list * unite_lexicale list =
  ([NOEUDS (S,
     [NOEUDS (EXPR,
       [NOEUDS (TERMB,
         [NOEUDS (FACTEURB,
           [FEUILLE UL_PAROUV;
            NOEUDS (EXPR,
             [NOEUDS (TERMB,
               [NOEUDS (FACTEURB,
                 [NOEUDS (RELATION,
                   [FEUILLE (UL_IDENT "z2");
                    NOEUDS (OP, [FEUILLE UL_INFERIEUR]);
                    FEUILLE (UL_IDENT "z1")])]);
                NOEUDS (SUITETERMB, [])]);
              NOEUDS (SUITEEXPR, [])]);
            FEUILLE UL_PARFERM]);
          NOEUDS (SUITETERMB, [])]);
        NOEUDS (SUITEEXPR,
         [FEUILLE UL_OU;
          NOEUDS (TERMB,
           [NOEUDS (FACTEURB,
             [FEUILLE UL_PAROUV;
              NOEUDS (EXPR,
               [NOEUDS (TERMB,
                 [NOEUDS (FACTEURB,
                   [NOEUDS (RELATION,
                     [FEUILLE (UL_IDENT "z2");
                      NOEUDS (OP, [FEUILLE UL_INFERIEUR]);
                      FEUILLE (UL_IDENT "z1")])]);
                  NOEUDS (SUITETERMB, [])]);
                NOEUDS (SUITEEXPR, [])]);
              FEUILLE UL_PARFERM]);
            NOEUDS (SUITETERMB, [])]);
          NOEUDS (SUITEEXPR, [])])]);
      FEUILLE UL_EOF])],
   [])
# val arbre_abstr : arbre_abstrait =
  Dijon (Comp ("z2", Op_inf, "z1"), Comp ("z2", Op_inf, "z1"))AT TEST 1*************************)


(* Arbres OK*)

(*CONCLUSIONS DES TEST*)

(*Aucun bug na �t� retennu dans ces test assez exhausifs, les arbres concrets et abstraits se construisent parfaitement.*)

(**************************FIN DES TEST ******************************************************)