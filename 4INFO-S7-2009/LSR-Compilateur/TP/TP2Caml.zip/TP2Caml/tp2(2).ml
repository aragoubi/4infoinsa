(*#use "tp1.ml";;*)
open Analex;;

type vn = S| EXPR | SUITEEXPR | TERMB | SUITETERMB | FACTEURB | RELATION | SUITEIDENT
type vt =  IDENT | OP | OU | ET | SI | ALORS | SINON | FSI | EOF | PAROUV | PARFERM
type v = VN of vn | VT of vt

type arbre_concret = FEUILLE of unite_lexicale | NOEUDS of  vn*(arbre_concret list)


exception Pas_de_codage
let codage = function

 UL_IDENT s -> IDENT
 | UL_PAROUV -> PAROUV
 | UL_PARFERM -> PARFERM
 | UL_OU  -> OU
 | UL_ET -> ET
 | UL_EOF -> EOF
 |  UL_SI -> SI
 | UL_ALORS ->ALORS
 | UL_SINON -> SINON
 | UL_FSI -> FSI
 | UL_EGAL | UL_DIFF | UL_INF | UL_SUP -> OP
 | _ -> raise Pas_de_codage



exception Pas_de_derivation

type derivation = vn * unite_lexicale->v list

let (ma_derivation : derivation) = function (vn1,ul1) ->
 ( match vn1 with 
      S -> (match ul1 with UL_IDENT _ | UL_PAROUV | UL_SI -> (VN EXPR)::(VT EOF)::[] 
	      | _ ->raise Pas_de_derivation )

    | EXPR ->(match ul1 with UL_IDENT _ | UL_PAROUV | UL_SI -> (VN TERMB)::(VN SUITEEXPR)::[]  
		| _ ->raise Pas_de_derivation)

    | SUITEEXPR -> (match ul1 with UL_OU | UL_IDENT _ | UL_PAROUV | UL_SI -> (VT OU)::(VN TERMB)::(VN SUITEEXPR)::[] 
		      | _ -> raise Pas_de_derivation )

    | TERMB ->(match ul1 with UL_IDENT _ | UL_PAROUV | UL_SI -> (VN FACTEURB)::(VN SUITETERMB)::[] 
		 | _ ->raise Pas_de_derivation)

    | SUITETERMB -> (match ul1 with UL_ET | UL_IDENT _ | UL_PAROUV | UL_SI -> (VT ET)::(VN FACTEURB)::(VN SUITETERMB)::[] 
		       | _ -> raise  Pas_de_derivation )

    | FACTEURB -> (match ul1 with (UL_IDENT _) -> [VN RELATION] | UL_PAROUV -> (VT PAROUV)::(VN EXPR)::(VT PARFERM)::[]
	                         | UL_SI -> (VT SI)::(VN EXPR)::(VT ALORS)::(VN EXPR)::(VT SINON)::(VN EXPR)::(VT FSI)::[] 
				 | _ -> raise Pas_de_derivation)

    | RELATION ->  (match ul1 with (UL_IDENT _) -> (VT IDENT)::(VT OP)::(VT IDENT)::[] 
		      | _ -> raise Pas_de_derivation)

    | _ ->raise Pas_de_derivation)

(*

(*ma_derivation (S,UL_IDENT "asdo");;*)

exception Ul_dif_du_carac

let rec analyse_caractere v liste_uls ->
  let ul_lue::reste = liste_uls in
    match v with
	(*si le caractère v est un terminal*)
	(*on vérifie que l'unité lexicale en tete de la liste correspond à ce caractère*)
	vt t -> if t=(codage ul_lue) then (FEUILLE ul_lue)  else raise Ul_dif_du_carac
	  (*si le caractere est non terminal, on créé un noeuyd ayant pour fils la liste d'arbre concret créé par analyse_mot*)
      | vn n -> NOEUDS (n,analyse_mot (derivation v)  reste)

and analyse_mot (mot : v list) liste_uls  = 
match mot with 
    (* cas liste vide*)
    [] -> []

      (* cas liste non vide*)
  | v::fin_mot -> let (arbre,liste_uls_restantes) = analyse_caractere v liste_uls; (liste_arbres,liste_uls_restantes) = analyse_mot fin_mot liste_uls_restantes in
((arbre::liste_arbres),listeliste_uls_restantes);;


type arbre_abstrait = Comp of string*op*string 
| Conj of arbre_abstrait*arbre_abstrait
| Dij of arbre_abstrait*arbre_abstrait
| Cond of arbre_abstrait*arbre_abstrait*arbre_abstrait

let rec construit_arbre_abstrait = function NOEUDS(nt,l) ->
 ( match (nt,l) with
  S,l -> construit_arbre_abstrait(hd l)

|EXPR,[a;NOEUDS (SUITETERMB,[]) -> construit_arbre_abstrait a

|EXPR,[a;NOEUDS(SUITETERMB,[FEUILLE UL_ou;b] -> Dij ((construit_arbre_abstrait a) (construit_arbre_abstrait b))

|TERMB,[a;NOEUDS(SUITETERMB, [])] -> construit_arbre_abstrait a

|TERMB,[a;NOEUDS(SUITETERMB,[FEUILLE UL_et;b] )] -> Conj ((construit_arbre_abstrait a) (construit_arbre_abstrait b))

|FACTEURB,[a;NOEUDS(RELATION,[])] -> (construit_arbre_abstrait a)

|FACTEURB,[a;NOEUDS(,[])] -> (construit_arbre_abstrait a)



*)
