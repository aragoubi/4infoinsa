(z2 < z1) et (z2 < z1)
