package clients.net.webservicex;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.xml.ws.Endpoint;

import net.webservicex.GeoIPService;
import net.webservicex.GeoIPServiceSoap;



@WebService
public class Client1Appel {
	
	@WebMethod
	public String quelTempsFaitIl(String pays, String ville){
		System.setProperty("http.proxyHost", "proxy.insa-rennes.fr");
		System.setProperty("http.proxyPort", "8080");
		
		GlobalWeather global = new GlobalWeather();
		GlobalWeatherSoap port = global.getGlobalWeatherSoap();
		
		return port.getWeather(ville, pays);
	}
	
	@WebMethod
	public String geoIP(String ip){
		System.setProperty("http.proxyHost", "proxy.insa-rennes.fr");
		System.setProperty("http.proxyPort", "8080");
		
		GeoIPService service = new GeoIPService();
		GeoIPServiceSoap portIP = service.getGeoIPServiceSoap();
		
		return portIP.getGeoIP(ip).getCountryName();
	}
	
	
	public static void main(String[] args) {
		
		Endpoint.publish(
	         "http://localhost:8080/boGosse",
	         new Client1Appel());
		
/*		
		try { // Call Web Service Operation
			
			System.setProperty("http.proxyHost", "proxy.insa-rennes.fr");
			System.setProperty("http.proxyPort", "8080");

			GlobalWeather global = new GlobalWeather();
			GlobalWeatherSoap port = global.getGlobalWeatherSoap();
			
			System.out.println("temps : " + port.getWeather("Rennes", "France"));
			
			GeoIPService service = new GeoIPService();
			GeoIPServiceSoap portIP = service.getGeoIPServiceSoap();
			
			System.out.println(portIP.getGeoIP("193.52.94.5").getCountryName());
        }
		catch (Exception ex) {
			System.err.println(ex.getMessage());
        }
*/
    }
}
