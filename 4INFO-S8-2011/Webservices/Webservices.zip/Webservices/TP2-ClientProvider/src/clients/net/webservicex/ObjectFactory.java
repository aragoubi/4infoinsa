
package clients.net.webservicex;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the clients.net.webservicex package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _QuelTempsFaitIlResponse_QNAME = new QName("http://webservicex.net.clients/", "quelTempsFaitIlResponse");
    private final static QName _QuelTempsFaitIl_QNAME = new QName("http://webservicex.net.clients/", "quelTempsFaitIl");
    private final static QName _GeoIPResponse_QNAME = new QName("http://webservicex.net.clients/", "geoIPResponse");
    private final static QName _GeoIP_QNAME = new QName("http://webservicex.net.clients/", "geoIP");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: clients.net.webservicex
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GeoIP }
     * 
     */
    public GeoIP createGeoIP() {
        return new GeoIP();
    }

    /**
     * Create an instance of {@link QuelTempsFaitIlResponse }
     * 
     */
    public QuelTempsFaitIlResponse createQuelTempsFaitIlResponse() {
        return new QuelTempsFaitIlResponse();
    }

    /**
     * Create an instance of {@link GeoIPResponse }
     * 
     */
    public GeoIPResponse createGeoIPResponse() {
        return new GeoIPResponse();
    }

    /**
     * Create an instance of {@link QuelTempsFaitIl }
     * 
     */
    public QuelTempsFaitIl createQuelTempsFaitIl() {
        return new QuelTempsFaitIl();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QuelTempsFaitIlResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservicex.net.clients/", name = "quelTempsFaitIlResponse")
    public JAXBElement<QuelTempsFaitIlResponse> createQuelTempsFaitIlResponse(QuelTempsFaitIlResponse value) {
        return new JAXBElement<QuelTempsFaitIlResponse>(_QuelTempsFaitIlResponse_QNAME, QuelTempsFaitIlResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QuelTempsFaitIl }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservicex.net.clients/", name = "quelTempsFaitIl")
    public JAXBElement<QuelTempsFaitIl> createQuelTempsFaitIl(QuelTempsFaitIl value) {
        return new JAXBElement<QuelTempsFaitIl>(_QuelTempsFaitIl_QNAME, QuelTempsFaitIl.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GeoIPResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservicex.net.clients/", name = "geoIPResponse")
    public JAXBElement<GeoIPResponse> createGeoIPResponse(GeoIPResponse value) {
        return new JAXBElement<GeoIPResponse>(_GeoIPResponse_QNAME, GeoIPResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GeoIP }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservicex.net.clients/", name = "geoIP")
    public JAXBElement<GeoIP> createGeoIP(GeoIP value) {
        return new JAXBElement<GeoIP>(_GeoIP_QNAME, GeoIP.class, null, value);
    }

}
