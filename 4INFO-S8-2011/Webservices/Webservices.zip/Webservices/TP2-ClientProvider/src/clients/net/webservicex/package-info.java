@javax.xml.bind.annotation.XmlSchema(namespace = "http://webservicex.net.clients/")
package clients.net.webservicex;
