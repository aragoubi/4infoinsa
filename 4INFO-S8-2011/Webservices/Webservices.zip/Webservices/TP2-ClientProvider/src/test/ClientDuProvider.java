package test;

import clients.net.webservicex.*;

public class ClientDuProvider {

	public static void main(String[] args) {
		try { // Call Web Service Operation
			System.setProperty("http.proxyHost", "proxy.insa-rennes.fr");
			System.setProperty("http.proxyPort", "8080");

			Client1AppelService service = new Client1AppelService();
			Client1Appel port = service.getClient1AppelPort();
			
			System.out.println("Temps à rennes : " + port.quelTempsFaitIl("France", "Rennes"));
			System.out.println("Votre pays : " + port.geoIP("193.52.94.5"));
			
		}
		catch (Exception ex) {
			System.err.println(ex.getMessage());
        }
	}
}
