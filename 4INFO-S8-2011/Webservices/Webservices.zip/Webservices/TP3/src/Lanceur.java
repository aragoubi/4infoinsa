

public class Lanceur {

	public static void main(String [] args){
		IntEvt evt;
		
		Thread.currentThread().setName("MainThread");
		
		evt = new IntEvt();
		
		new Thread(new Lecteur1(evt), "lecteur 1").start();
		new Thread(new Lecteur2(evt), "lecteur 2").start();
		
		evt.write(10);
	}
}
