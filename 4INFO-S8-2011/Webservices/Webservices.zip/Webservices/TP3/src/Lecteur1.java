
public class Lecteur1 implements Runnable{
	IntEvt evt;
	int c = 3, d = 4, V1;
	
	public Lecteur1(IntEvt e){
		evt = e;
	}
	
	public void run(){
		V1 = evt.read() + c * d;
	}
}
