
public class AccessViolationException extends Exception{
}
