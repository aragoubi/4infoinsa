
public class Lecteur2 implements Runnable{
		IntEvt evt;
		int f = 11, V2;
		
		public Lecteur2(IntEvt e){
			evt = e;
		}
		
		public void run(){
			V2 = evt.read() + f;
		}
	}
