
public class Ecrivain {

}
