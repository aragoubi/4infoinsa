
public class IntEvt {
	Thread auteur;
	boolean dejaEcrit;
	int value;

	public IntEvt(){
		dejaEcrit = false;
		auteur = Thread.currentThread();
	}
	
	public int read(){
		if(!dejaEcrit){
				try {
					synchronized(this){
						System.out.println("[" + Thread.currentThread().getName() + "] pas encore écrit, blocage.");
						this.wait();
					}
				} catch (InterruptedException e) {
					e.printStackTrace();
			}
		}
			
		System.out.println("[" + Thread.currentThread().getName() + "] c'est bon je renvoie la valeur");
			
		return value;
	}
	
	public synchronized void write(int i){
		if(Thread.currentThread() == auteur && !dejaEcrit){
			
			value = i;
			dejaEcrit = true;
			System.out.println("[" + Thread.currentThread().getName() + "] écriture " + i);
			this.notifyAll();
		}
	}
}
