import java.util.Calendar;


public class Lanceur2 {
	
	public static IntEvt2 evt;

	public static void main(String [] args){
		evt = new IntEvt2();
		
		for(int i = 0; i < 10; i++){
			new Thread(new Runnable(){
				public void run(){
					while(true){
						try {
							int val = evt.read();
							//System.out.println("["+ Thread.currentThread().getName()+"] valeur = " + val);
						}
						catch (AccessViolationException e) {
							System.out.println("["+ Thread.currentThread().getName()+"] Je fais autre chooooooooooooooooose");
						}
						
						try {
							Thread.sleep(500);
						} catch (InterruptedException e1) {
						}
					}
				}
			}, "lecteur " + i).start();
			
			
			if(i == 0){
				new Thread(new Runnable(){
					public void run(){
						while(true){
							try {
								int val = (int)Calendar.getInstance().getTimeInMillis();
								evt.write(val);
								System.out.println("["+ Thread.currentThread().getName()+"] je viens d'écrire " + val);
							}
							catch (AccessViolationException e) {
								System.out.println("["+ Thread.currentThread().getName()+"] Je fais autre chooooooooooooooooose");
							}
							
							try {
								Thread.sleep(1000);
							} catch (InterruptedException e1) {
							}
						}
					}
				}, "ecrivain " + i).start();
			}
		}
		
		
		
		
	}
}
