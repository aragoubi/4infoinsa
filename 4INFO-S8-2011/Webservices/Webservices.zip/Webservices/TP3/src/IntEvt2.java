import java.util.concurrent.locks.Condition;


public class IntEvt2 {
	int value, nbLect, nbEcr;
	int nbEcrAttente;

	public IntEvt2(){
		nbLect = 0;
		nbEcr = 0;
		value = -1;
		nbEcrAttente = 0;
	}
	
	public void debutLire() throws AccessViolationException{
		nbLect++;
		
		if(nbEcrAttente > 0 || nbEcr > 0 || value == -1){
			nbLect--;
			throw new AccessViolationException();
		}
	}
	
	public int lire(){
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return value;
	}
	
	public void finLire(){
		nbLect--;
	}
	
	public int read() throws AccessViolationException{
		debutLire();
		int val = lire();
		finLire();
		
		return val;
	}
	
	public void debutEcrire() throws AccessViolationException{
		nbEcr++;
		
		if(nbEcrAttente == 0)
			nbEcrAttente++;
		
		if(nbEcr > 1 || nbLect > 0){
			nbEcr--;
			throw new AccessViolationException();
		}
		
		nbEcrAttente--;
	}
	
	public void ecrire(int i){
		value = i;
	}
	
	public void finEcrire(){
		nbEcr--;
	}
	
	public void write(int i) throws AccessViolationException{
		debutEcrire();
		ecrire(i);
		finEcrire();
	}
}
