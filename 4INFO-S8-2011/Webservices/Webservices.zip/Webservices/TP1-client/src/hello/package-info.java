@javax.xml.bind.annotation.XmlSchema(namespace = "http://hello/")
package hello;
