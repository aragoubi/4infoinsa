package calculatrice;

public class ClientCalculatrice {
	public static void main(String[] args) {
		System.out.println("a");
		try { // Call Web Service Operation
           calculatrice.CalculatriceService service =
                new calculatrice.CalculatriceService();
            calculatrice.Calculatrice port = service.getCalculatricePort();
            
            double t1 = 100;
            double t2 = 1;
            double result = port.addition(t1, t2);
            System.out.println("Result = "+result);
        } catch (Exception ex) {
            // TODO handle custom exceptions here
        }
        // TODO code application logic here
    }

}
