@javax.xml.bind.annotation.XmlSchema(namespace = "http://calculatrice/")
package calculatrice;
