package calculatrice;


import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.xml.ws.Endpoint;
@WebService

public class Calculatrice {
   @WebMethod public double addition(double t1, double t2) {
       return t1 + t2;
    }

   @WebMethod public double multiplication(double t1, double t2) {
       return t1 * t2;
    }
   
   @WebMethod public double soustraction(double t1, double t2) {
       return t1 - t2;
    }
   
   @WebMethod public double division(double t1, double t2) {
       return t1 / t2;
    }



public static void main(String[] args) {

      Endpoint.publish(
         "http://localhost:8080/calculatrice",
         new Calculatrice());

	}
}
