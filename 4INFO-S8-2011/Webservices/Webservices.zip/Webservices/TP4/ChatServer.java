package chat;

import java.rmi.RemoteException;

/**
*   This is the remote interface that describes the methods
*   that the client can call on the server
*/

public interface ChatServer extends java.rmi.Remote {


	/**
	*   The client retrieves all the messages that are on the server
	*/
    public String[] getAllMessages() throws RemoteException;

	/**
	*   The client adds a new message to the list
	*/
    public void addNewMessage(String m) throws RemoteException;
    public void sendmsg(String m) throws RemoteException;
    
    public void connect(ChatClient ref) throws RemoteException;
    public void disconnect(ChatClient ref) throws RemoteException;


}
