package executionservice.impl;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import executionservice.WorkerRegistration;

public class CalculePI {
	
	static final int NUMTASKS = 10;
	static final int NUMWORKERS = 10;
	static final long NUMPOINTS = 10000L;
	
	static private List<Integer> ids = new ArrayList<Integer>();
	
	public static void main(String [] args){
		ExecutionServiceImpl es;
		try {
			es = new ExecutionServiceImpl();
			
			WorkerRegistration wr = (WorkerRegistration) es;
			
			// Creates a set of workers 
			for (int i = 0; i < NUMWORKERS; i++) {
				new Worker(wr, "wrk" + i).start();
			}

			// Starts timing.
			long time = System.currentTimeMillis();

			// Submits a set of tasks; each task calculates a different PI number
			for (int i = 0; i < NUMTASKS; i++) {
				int id = es.submitTask(new PiTask(NUMPOINTS));
				ids.add(id);
			}

			// Gets all the task results, waiting if necessary
			long count = 0;
			for (Integer i : ids) {
				try {
					long res = es.getResult(i);
					count += res;
					System.out.println("res = " + res);
					
					System.out.println("count = " + count);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			System.out.println("Nombre de points = " + (NUMPOINTS));
			System.out.println("Nombre de points dans le cercle = " + count);
			System.out.println("PI = " + (4.0 * count / (NUMPOINTS * NUMWORKERS)));

			// Stops timing.
			time = System.currentTimeMillis() - time;
			System.out.println("Time :" + time + " ms");
		} catch (RemoteException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

}
