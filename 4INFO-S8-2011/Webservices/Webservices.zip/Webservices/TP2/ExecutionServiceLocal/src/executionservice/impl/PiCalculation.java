package executionservice.impl;

import java.util.Random;

public class PiCalculation {
	static long NUM_POINTS = 10000000L;

	public static double calculatePi() {

		long count = 0;

		Random prng = new Random();

		// Generate n random points in a unit square and count how many are
		// within the inscribed circle.
		for (int i = 0; i < NUM_POINTS; ++i) {
			double x = prng.nextDouble();
			double y = prng.nextDouble();
			if (x * x + y * y <= 1.0)
				count++;
		}
		// The fraction of the points within the circle gives an approximation for pi/4 
		return (4.0 * count / NUM_POINTS);
	}

	public static void main(String[] args) {

		// Start timing.
		long time = System.currentTimeMillis();
		double pi = calculatePi();

		// Stop timing.
		time=System.currentTimeMillis()-time;

		// Print results.
		System.out.println("Time: "+time+" ms");
		System.out.println("Pi approximation= " + pi);

	}
}
