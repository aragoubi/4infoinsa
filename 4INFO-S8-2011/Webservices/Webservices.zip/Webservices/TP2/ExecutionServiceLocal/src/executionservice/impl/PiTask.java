package executionservice.impl;

import java.rmi.server.UnicastRemoteObject;
import java.util.Random;

import executionservice.Task;

public class PiTask implements Task{
	
	private long nbPoints;
	
	public PiTask(long nbPoints){
			this.nbPoints = nbPoints;
		}

	@Override
	public long execute() {
		long count = 0;

		Random prng = new Random();

		// Generate n random points in a unit square and count how many are
		// within the inscribed circle.
		for (int i = 0; i < nbPoints; ++i) {
			double x = prng.nextDouble();
			double y = prng.nextDouble();
			if (x * x + y * y <= 1.0)
				count++;
		}
		// The fraction of the points within the circle gives an approximation for pi/4 
		return count;
	}

}
