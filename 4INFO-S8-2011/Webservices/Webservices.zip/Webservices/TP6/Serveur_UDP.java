import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.Calendar;

import com.sun.xml.internal.ws.util.ByteArrayBuffer;


public class Serveur_UDP {

	private DatagramSocket socket;
	
	private DatagramPacket reception;
	private DatagramPacket envoie;
	
	private byte [] buf;
	
	public Serveur_UDP(){
		try {
			socket = new DatagramSocket(50001);
			buf = new byte[256];
			
			while(true){
				
				reception = new DatagramPacket(buf, 256);
				socket.receive(reception);
				
				Calendar date = Calendar.getInstance();
				
				buf = new byte[256];
				buf[0] = new Byte(new Integer(date.get(Calendar.DAY_OF_MONTH)).byteValue());
				buf[1] = new Byte(new Integer((date.get(Calendar.MONTH)+1)).byteValue());
				//buf[2] = new Byte(new Integer(date.get(Calendar.YEAR)).byteValue());
				buf[2] = new Byte(new Integer(11).byteValue());
				
				envoie = new DatagramPacket(buf, buf.length, reception.getAddress(), reception.getPort());
				
				socket.send(envoie);
			}
		} catch (SocketException e) {
			System.err.println("Erreur creation socket");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("Erreur reception");
			e.printStackTrace();
		}
	}
	
	public static void main(String [] args){
		Serveur_UDP serveur = new Serveur_UDP();
	}
}
