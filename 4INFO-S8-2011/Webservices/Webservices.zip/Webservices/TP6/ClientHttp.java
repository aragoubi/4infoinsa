import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;



public class ClientHttp {
	
	private Socket socket;

	public ClientHttp(){
		try {
			System.setProperty("HttpHost", "proxy.insa-rennes.fr");
			System.setProperty("HttpPort", "8080");
			
			for(int i = 0; i < 10; i++){
				socket = new Socket("vichy", 8888);
				
				OutputStream out = socket.getOutputStream();
				OutputStreamWriter writer = new OutputStreamWriter(out);
				BufferedWriter buf = new BufferedWriter(writer);
				buf.append("Coucou le serveur\n");
				buf.flush();
				socket.close();
			}
			
		} catch (UnknownHostException e) {
			System.err.println("Hôte inconnu");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("Erreur creation socket");
			e.printStackTrace();
		}
		
	}
	
	public static void main(String [] args){
		for(int i = 0; i < 5; i++){
			ClientHttp client = new ClientHttp();
		}
	}
}
